import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView, TextInput } from 'react-native';
import { router } from 'expo-router';
import { commonStyles, colors } from '../styles/commonStyles';
import Button from '../components/Button';
import Icon from '../components/Icon';

interface Fighter {
  name: string;
  points: number;
  advantages: number;
  penalties: number;
}

export default function GrapplingScorekeeper() {
  const [time, setTime] = useState(300); // 5 minutes par défaut
  const [isRunning, setIsRunning] = useState(false);
  const [fighter1, setFighter1] = useState<Fighter>({
    name: 'Combattant 1',
    points: 0,
    advantages: 0,
    penalties: 0
  });
  const [fighter2, setFighter2] = useState<Fighter>({
    name: 'Combattant 2',
    points: 0,
    advantages: 0,
    penalties: 0
  });
  const [editingFighter1Name, setEditingFighter1Name] = useState(false);
  const [editingFighter2Name, setEditingFighter2Name] = useState(false);
  const [showQuickActions, setShowQuickActions] = useState(false);

  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const maxTime = 600; // 10 minutes maximum

  useEffect(() => {
    if (isRunning && time > 0) {
      intervalRef.current = setInterval(() => {
        setTime(prevTime => {
          if (prevTime <= 1) {
            setIsRunning(false);
            Alert.alert('Temps écoulé!', 'Le match est terminé.');
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, time]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const toggleTimer = () => {
    console.log('Timer toggled:', !isRunning);
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    console.log('Timer reset');
    setIsRunning(false);
    setTime(300);
  };

  const adjustTime = (delta: number) => {
    const newTime = Math.max(0, Math.min(maxTime, time + delta));
    setTime(newTime);
    console.log('Time adjusted to:', newTime);
  };

  const resetMatch = () => {
    console.log('Match reset');
    Alert.alert(
      'Réinitialiser le match',
      'Êtes-vous sûr de vouloir réinitialiser le match?',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Réinitialiser',
          style: 'destructive',
          onPress: () => {
            setIsRunning(false);
            setTime(300);
            setFighter1({ name: 'Combattant 1', points: 0, advantages: 0, penalties: 0 });
            setFighter2({ name: 'Combattant 2', points: 0, advantages: 0, penalties: 0 });
            setEditingFighter1Name(false);
            setEditingFighter2Name(false);
          }
        }
      ]
    );
  };

  const updateFighter1 = (field: keyof Omit<Fighter, 'name'>, delta: number) => {
    setFighter1(prev => ({
      ...prev,
      [field]: Math.max(0, prev[field] + delta)
    }));
    console.log(`Fighter 1 ${field} updated:`, fighter1[field] + delta);
  };

  const updateFighter2 = (field: keyof Omit<Fighter, 'name'>, delta: number) => {
    setFighter2(prev => ({
      ...prev,
      [field]: Math.max(0, prev[field] + delta)
    }));
    console.log(`Fighter 2 ${field} updated:`, fighter2[field] + delta);
  };

  const updateFighterName = (fighterNumber: 1 | 2, newName: string) => {
    if (fighterNumber === 1) {
      setFighter1(prev => ({ ...prev, name: newName }));
    } else {
      setFighter2(prev => ({ ...prev, name: newName }));
    }
    console.log(`Fighter ${fighterNumber} name updated to:`, newName);
  };

  const getWinner = (): string => {
    const score1 = fighter1.points + (fighter1.advantages * 0.1) - (fighter1.penalties * 0.5);
    const score2 = fighter2.points + (fighter2.advantages * 0.1) - (fighter2.penalties * 0.5);
    
    if (score1 > score2) return fighter1.name;
    if (score2 > score1) return fighter2.name;
    return 'Égalité';
  };

  const quickActionButtons = [
    { label: '+2 pts', action: (fighter: 1 | 2) => fighter === 1 ? updateFighter1('points', 2) : updateFighter2('points', 2), color: colors.primary },
    { label: '+3 pts', action: (fighter: 1 | 2) => fighter === 1 ? updateFighter1('points', 3) : updateFighter2('points', 3), color: colors.primary },
    { label: '+4 pts', action: (fighter: 1 | 2) => fighter === 1 ? updateFighter1('points', 4) : updateFighter2('points', 4), color: colors.primary },
    { label: '+Avantage', action: (fighter: 1 | 2) => fighter === 1 ? updateFighter1('advantages', 1) : updateFighter2('advantages', 1), color: colors.accent },
    { label: '+Pénalité', action: (fighter: 1 | 2) => fighter === 1 ? updateFighter1('penalties', 1) : updateFighter2('penalties', 1), color: '#FF6B6B' },
  ];

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Icon name="arrow-back" size={24} />
        </TouchableOpacity>
        <Text style={styles.title}>Compteur Grappling</Text>
        <TouchableOpacity onPress={resetMatch} style={styles.resetButton}>
          <Icon name="refresh" size={24} />
        </TouchableOpacity>
      </View>

      {/* Timer Section */}
      <View style={styles.timerSection}>
        <View style={styles.timerAdjustRow}>
          <TouchableOpacity 
            style={styles.timeAdjustButton}
            onPress={() => adjustTime(-10)}
            disabled={time <= 0}
          >
            <Icon name="remove" size={20} />
            <Text style={styles.timeAdjustText}>-10s</Text>
          </TouchableOpacity>
          
          <Text style={styles.timerText}>{formatTime(time)}</Text>
          
          <TouchableOpacity 
            style={styles.timeAdjustButton}
            onPress={() => adjustTime(10)}
            disabled={time >= maxTime}
          >
            <Icon name="add" size={20} />
            <Text style={styles.timeAdjustText}>+10s</Text>
          </TouchableOpacity>
        </View>
        
        <Text style={styles.maxTimeText}>Max: {formatTime(maxTime)}</Text>
        
        <View style={styles.timerControls}>
          <TouchableOpacity 
            style={[styles.timerButton, isRunning ? styles.pauseButton : styles.playButton]}
            onPress={toggleTimer}
          >
            <Icon name={isRunning ? "pause" : "play"} size={24} />
            <Text style={styles.timerButtonText}>
              {isRunning ? 'Pause' : 'Start'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.timerButton} onPress={resetTimer}>
            <Icon name="stop" size={24} />
            <Text style={styles.timerButtonText}>Reset</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Quick Actions Toggle */}
      <View style={styles.quickActionsToggle}>
        <TouchableOpacity 
          style={styles.quickActionsToggleButton}
          onPress={() => setShowQuickActions(!showQuickActions)}
        >
          <Icon name={showQuickActions ? "chevron-up" : "chevron-down"} size={20} />
          <Text style={styles.quickActionsToggleText}>Actions Rapides</Text>
        </TouchableOpacity>
      </View>

      {/* Quick Actions Panel */}
      {showQuickActions && (
        <View style={styles.quickActionsPanel}>
          <Text style={styles.quickActionsPanelTitle}>Sélectionnez le combattant puis l&apos;action</Text>
          <View style={styles.fighterSelectionRow}>
            <Text style={styles.fighterSelectionLabel}>Combattant:</Text>
            <View style={styles.fighterButtons}>
              <Text style={styles.fighterButtonLabel}>{fighter1.name}</Text>
              <Text style={styles.fighterButtonLabel}>{fighter2.name}</Text>
            </View>
          </View>
          
          {quickActionButtons.map((button, index) => (
            <View key={index} style={styles.quickActionRow}>
              <Text style={styles.quickActionLabel}>{button.label}</Text>
              <View style={styles.quickActionButtons}>
                <TouchableOpacity 
                  style={[styles.quickActionButton, { backgroundColor: button.color }]}
                  onPress={() => button.action(1)}
                >
                  <Text style={styles.quickActionButtonText}>F1</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.quickActionButton, { backgroundColor: button.color }]}
                  onPress={() => button.action(2)}
                >
                  <Text style={styles.quickActionButtonText}>F2</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      )}

      {/* Scores Section */}
      <View style={styles.scoresContainer}>
        {/* Fighter 1 */}
        <View style={styles.fighterCard}>
          {editingFighter1Name ? (
            <TextInput
              style={styles.fighterNameInput}
              value={fighter1.name}
              onChangeText={(text) => updateFighterName(1, text)}
              onBlur={() => setEditingFighter1Name(false)}
              onSubmitEditing={() => setEditingFighter1Name(false)}
              autoFocus
              selectTextOnFocus
              placeholder="Nom du combattant 1"
              placeholderTextColor={colors.textSecondary}
            />
          ) : (
            <TouchableOpacity onPress={() => setEditingFighter1Name(true)}>
              <Text style={styles.fighterName}>{fighter1.name}</Text>
              <Text style={styles.editHint}>Appuyez pour modifier</Text>
            </TouchableOpacity>
          )}
          
          <View style={styles.scoreRow}>
            <Text style={styles.scoreLabel}>Points</Text>
            <View style={styles.scoreControls}>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter1('points', -1)}
              >
                <Text style={styles.scoreButtonText}>-</Text>
              </TouchableOpacity>
              <Text style={styles.scoreValue}>{fighter1.points}</Text>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter1('points', 1)}
              >
                <Text style={styles.scoreButtonText}>+</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.scoreRow}>
            <Text style={styles.scoreLabel}>Avantages</Text>
            <View style={styles.scoreControls}>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter1('advantages', -1)}
              >
                <Text style={styles.scoreButtonText}>-</Text>
              </TouchableOpacity>
              <Text style={styles.scoreValue}>{fighter1.advantages}</Text>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter1('advantages', 1)}
              >
                <Text style={styles.scoreButtonText}>+</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.scoreRow}>
            <Text style={styles.scoreLabel}>Pénalités</Text>
            <View style={styles.scoreControls}>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter1('penalties', -1)}
              >
                <Text style={styles.scoreButtonText}>-</Text>
              </TouchableOpacity>
              <Text style={styles.scoreValue}>{fighter1.penalties}</Text>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter1('penalties', 1)}
              >
                <Text style={styles.scoreButtonText}>+</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* VS Divider */}
        <View style={styles.vsContainer}>
          <Text style={styles.vsText}>VS</Text>
        </View>

        {/* Fighter 2 */}
        <View style={styles.fighterCard}>
          {editingFighter2Name ? (
            <TextInput
              style={styles.fighterNameInput}
              value={fighter2.name}
              onChangeText={(text) => updateFighterName(2, text)}
              onBlur={() => setEditingFighter2Name(false)}
              onSubmitEditing={() => setEditingFighter2Name(false)}
              autoFocus
              selectTextOnFocus
              placeholder="Nom du combattant 2"
              placeholderTextColor={colors.textSecondary}
            />
          ) : (
            <TouchableOpacity onPress={() => setEditingFighter2Name(true)}>
              <Text style={styles.fighterName}>{fighter2.name}</Text>
              <Text style={styles.editHint}>Appuyez pour modifier</Text>
            </TouchableOpacity>
          )}
          
          <View style={styles.scoreRow}>
            <Text style={styles.scoreLabel}>Points</Text>
            <View style={styles.scoreControls}>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter2('points', -1)}
              >
                <Text style={styles.scoreButtonText}>-</Text>
              </TouchableOpacity>
              <Text style={styles.scoreValue}>{fighter2.points}</Text>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter2('points', 1)}
              >
                <Text style={styles.scoreButtonText}>+</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.scoreRow}>
            <Text style={styles.scoreLabel}>Avantages</Text>
            <View style={styles.scoreControls}>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter2('advantages', -1)}
              >
                <Text style={styles.scoreButtonText}>-</Text>
              </TouchableOpacity>
              <Text style={styles.scoreValue}>{fighter2.advantages}</Text>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter2('advantages', 1)}
              >
                <Text style={styles.scoreButtonText}>+</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.scoreRow}>
            <Text style={styles.scoreLabel}>Pénalités</Text>
            <View style={styles.scoreControls}>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter2('penalties', -1)}
              >
                <Text style={styles.scoreButtonText}>-</Text>
              </TouchableOpacity>
              <Text style={styles.scoreValue}>{fighter2.penalties}</Text>
              <TouchableOpacity 
                style={styles.scoreButton}
                onPress={() => updateFighter2('penalties', 1)}
              >
                <Text style={styles.scoreButtonText}>+</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>

      {/* Winner Display */}
      {time === 0 && (
        <View style={styles.winnerSection}>
          <Text style={styles.winnerText}>Vainqueur: {getWinner()}</Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  backButton: {
    padding: 10,
    backgroundColor: colors.backgroundAlt,
    borderRadius: 8,
  },
  resetButton: {
    padding: 10,
    backgroundColor: colors.backgroundAlt,
    borderRadius: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  timerSection: {
    alignItems: 'center',
    paddingVertical: 30,
    backgroundColor: colors.backgroundAlt,
    marginHorizontal: 20,
    borderRadius: 15,
    marginBottom: 20,
  },
  timerAdjustRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    gap: 20,
  },
  timeAdjustButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: colors.primary,
    borderRadius: 20,
    gap: 4,
  },
  timeAdjustText: {
    color: colors.text,
    fontSize: 12,
    fontWeight: 'bold',
  },
  timerText: {
    fontSize: 48,
    fontWeight: 'bold',
    color: colors.text,
  },
  maxTimeText: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 20,
  },
  timerControls: {
    flexDirection: 'row',
    gap: 15,
  },
  timerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 25,
    gap: 8,
  },
  playButton: {
    backgroundColor: colors.accent,
  },
  pauseButton: {
    backgroundColor: '#FF6B6B',
  },
  timerButtonText: {
    color: colors.text,
    fontWeight: 'bold',
    fontSize: 16,
  },
  quickActionsToggle: {
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  quickActionsToggleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    backgroundColor: colors.backgroundAlt,
    borderRadius: 10,
    gap: 8,
  },
  quickActionsToggleText: {
    color: colors.text,
    fontWeight: 'bold',
    fontSize: 16,
  },
  quickActionsPanel: {
    backgroundColor: colors.backgroundAlt,
    marginHorizontal: 20,
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
  },
  quickActionsPanelTitle: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 15,
  },
  fighterSelectionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  fighterSelectionLabel: {
    fontSize: 14,
    color: colors.text,
    fontWeight: 'bold',
    flex: 1,
  },
  fighterButtons: {
    flexDirection: 'row',
    gap: 20,
    flex: 2,
  },
  fighterButtonLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'center',
    flex: 1,
  },
  quickActionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  quickActionLabel: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '600',
    flex: 1,
  },
  quickActionButtons: {
    flexDirection: 'row',
    gap: 10,
    flex: 1,
  },
  quickActionButton: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 6,
    alignItems: 'center',
  },
  quickActionButtonText: {
    color: colors.text,
    fontWeight: 'bold',
    fontSize: 12,
  },
  scoresContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  fighterCard: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
  },
  fighterName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 5,
  },
  fighterNameInput: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 15,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: colors.background,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: colors.accent,
  },
  editHint: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 15,
    fontStyle: 'italic',
  },
  scoreRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  scoreLabel: {
    fontSize: 16,
    color: colors.text,
    fontWeight: '600',
    flex: 1,
  },
  scoreControls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  scoreButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scoreButtonText: {
    color: colors.text,
    fontSize: 20,
    fontWeight: 'bold',
  },
  scoreValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    minWidth: 40,
    textAlign: 'center',
  },
  vsContainer: {
    alignItems: 'center',
    marginVertical: 10,
  },
  vsText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.accent,
  },
  winnerSection: {
    backgroundColor: colors.accent,
    marginHorizontal: 20,
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
  },
  winnerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.background,
  },
});